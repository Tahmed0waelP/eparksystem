<?php
// Set the content type to application/json
header('Content-Type: application/json');

// --- CONSTANT SENSOR DATA LOOKUP TABLE ---
// All static keys and values are defined here. 
// These values WILL NOT CHANGE and are merged with the ESP32 data.
$sensor_constants = [
    "T-4001-A" => [
        "sensor_place" => "Server Room 1",
        "sensor_location" => ["plus_code" => "26VQ+Q8"]
    ],
    "H-2055-B" => [
        "sensor_place" => "Warehouse Floor B",
        "sensor_location" => ["plus_code" => "26VQ+Q8"]
    ]
];

// 1. Get the raw POST data (minimal JSON from the ESP32)
$json_data = file_get_contents('php://input');
$received_data = json_decode($json_data, true);

// Check for errors in received data
if ($received_data === null || json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON data received.']);
    exit;
}

// 2. Process and merge the data
$final_output = [];

foreach ($received_data as $sensor_update) {
    $id = $sensor_update['sensor_id'] ?? null;
    $availability = $sensor_update['availability'] ?? null;

    // Check if the sensor ID is valid and availability is present
    if ($id && isset($sensor_constants[$id]) && $availability !== null) {
        
        // Merge the constant data from the lookup table with the variable availability
        $full_sensor_data = array_merge(
            ['sensor_id' => $id],               // 1. ID
            $sensor_constants[$id],             // 2. Constant details (place, location)
            ['availability' => $availability]   // 3. Variable status from ESP32
        );
        
        $final_output[] = $full_sensor_data;
    } else {
        // Handle case where sensor ID is unknown or data is incomplete
        error_log("Received unknown sensor ID or incomplete data: " . $id);
    }
}

// 3. Return the final reconstructed JSON array
if (empty($final_output)) {
    http_response_code(500); // Internal Server Error if no data was processed
    echo json_encode(['status' => 'error', 'message' => 'No valid sensor data was processed.']);
} else {
    // Success: Return the full, correctly structured JSON
    http_response_code(200);
    echo json_encode($final_output, JSON_PRETTY_PRINT);
}

?>