<?php
/****************************************************
 * WhatsApp Form (PHP) – Click-to-Chat or Cloud API
 * -------------------------------------------------
 * 1) Click-to-Chat: opens WhatsApp with a prefilled message (no API).
 * 2) Cloud API: sends a message via Meta WhatsApp Cloud API.
 ****************************************************/

// ============ CONFIG ============
// Mode: 'click_to_chat' OR 'cloud_api'
$MODE = 'click_to_chat';

// The WhatsApp number that should receive the form messages (E.164 format)
$RECIPIENT_NUMBER = '+201204014383';

// --- Cloud API settings (only needed if $MODE = 'cloud_api') ---
$PHONE_NUMBER_ID = 'YOUR_PHONE_NUMBER_ID';
$ACCESS_TOKEN    = 'YOUR_LONG_LIVED_ACCESS_TOKEN';
// Graph API version (keep current)
$GRAPH_VERSION   = 'v20.0';

// Optional: basic site info for the message header
$SITE_NAME = 'Contact Form';

// ============ END CONFIG ============

// Helper: sanitize string (basic)
function clean($v) {
  return trim(strip_tags($v ?? ''));
}

// Handle POST
$successMsg = $errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  // Simple honeypot to reduce bots
  if (!empty($_POST['website'])) { // hidden field should be empty
    $errorMsg = 'Something went wrong.';
  } else {
    $name    = clean($_POST['name'] ?? '');
    $phone   = clean($_POST['phone'] ?? '');
    $email   = clean($_POST['email'] ?? '');
    $message = clean($_POST['message'] ?? '');

    // Basic validation
    if ($name === '' || $message === '') {
      $errorMsg = 'Please fill in your name and message.';
    } else {
      // Build a neat WhatsApp text
      $lines = [
        "📩 New inquiry via $SITE_NAME",
        "— — — — — — —",
        "👤 Name: $name",
        $phone ? "📱 Phone: $phone" : null,
        $email ? "✉️ Email: $email" : null,
        "— — — — — — —",
        "📝 Message:",
        $message,
      ];
      $text = implode("\n", array_filter($lines, fn($l) => $l !== null));

      if ($MODE === 'click_to_chat') {
        // Redirect the user to WhatsApp with pre-filled message
        // Remove + for wa.me path; keep E.164 digits only
        $waNumber = preg_replace('/\D+/', '', $RECIPIENT_NUMBER);
        $url = 'https://wa.me/' . $waNumber . '?text=' . urlencode($text);
        header('Location: ' . $url);
        exit;

      } elseif ($MODE === 'cloud_api') {
        // Send via WhatsApp Cloud API
        $endpoint = "https://graph.facebook.com/$GRAPH_VERSION/$PHONE_NUMBER_ID/messages";
        $payload = [
          'messaging_product' => 'whatsapp',
          'to'                => $RECIPIENT_NUMBER,
          'type'              => 'text',
          'text'              => ['preview_url' => false, 'body' => $text],
        ];
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
          CURLOPT_POST           => true,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $ACCESS_TOKEN
          ],
          CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
          CURLOPT_TIMEOUT        => 15
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr) {
          $errorMsg = 'Network error: ' . htmlspecialchars($curlErr);
        } elseif ($httpCode >= 200 && $httpCode < 300) {
          $successMsg = 'Thanks! Your message was sent on WhatsApp.';
        } else {
          // Show a concise error for debugging
          $errorMsg = 'WhatsApp API error (HTTP ' . $httpCode . '). Response: ' . htmlspecialchars($response);
        }
      } else {
        $errorMsg = 'Invalid mode selected.';
      }
    }
  }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Contact via WhatsApp</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root{
      --bg:#0f172a;        /* slate-900 */
      --card:#111827;      /* gray-900 */
      --muted:#94a3b8;     /* slate-400 */
      --text:#e5e7eb;      /* gray-200 */
      --accent:#22c55e;    /* green-500 */
      --accent-2:#16a34a;  /* green-600 */
      --danger:#ef4444;    /* red-500 */
    }
    *{box-sizing:border-box;}
    body{
      margin:0; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
      background: radial-gradient(1200px 600px at 80% -10%, #1f2937 0%, var(--bg) 60%);
      color:var(--text);
      min-height:100vh; display:flex; align-items:center; justify-content:center; padding:24px;
    }
    .wrap{
      width:100%; max-width:760px;
    }
    .card{
      background: linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02));
      border:1px solid rgba(255,255,255,0.08);
      backdrop-filter: blur(6px);
      border-radius:18px; padding:28px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.45);
    }
    h1{
      margin:0 0 18px; font-size:28px; letter-spacing:.2px;
      display:flex; align-items:center; gap:10px;
    }
    h1 .dot{ width:12px; height:12px; border-radius:999px; background:var(--accent); display:inline-block;}
    p.sub{ color:var(--muted); margin-top:-6px; margin-bottom:22px; }
    form{ display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    .full{ grid-column:1 / -1; }
    label{ display:block; font-size:14px; color:var(--muted); margin-bottom:6px; }
    input, textarea{
      width:100%; background:#0b1220; color:var(--text);
      border:1px solid rgba(255,255,255,0.08);
      border-radius:12px; padding:12px 14px; font-size:16px;
      outline:none; transition: border .15s ease, box-shadow .15s ease;
    }
    input:focus, textarea:focus{
      border-color:rgba(34,197,94,.7);
      box-shadow:0 0 0 3px rgba(34,197,94,.15);
    }
    textarea{ min-height:140px; resize:vertical; }
    .actions{ display:flex; align-items:center; gap:12px; margin-top:6px; }
    button{
      appearance:none; border:0; cursor:pointer;
      background:linear-gradient(180deg, var(--accent), var(--accent-2));
      color:white; padding:12px 18px; border-radius:12px; font-weight:600; font-size:16px;
      transition: transform .06s ease;
    }
    button:active{ transform: translateY(1px); }
    .note{ color:var(--muted); font-size:13px; }
    .alert{
      margin-bottom:14px; padding:12px 14px; border-radius:12px; font-size:14px;
      border:1px solid rgba(255,255,255,0.12);
    }
    .ok{ background: rgba(34,197,94,0.15); border-color: rgba(34,197,94,0.35);}
    .bad{ background: rgba(239,68,68,0.15); border-color: rgba(239,68,68,0.35);}
    /* hide honeypot */
    .hp{ display:none !important; }
    @media (max-width:720px){
      form{ grid-template-columns:1fr; }
    }
    .mode-pill{
      display:inline-flex; align-items:center; gap:8px; font-size:12px; color:#a7f3d0;
      background: rgba(34,197,94,0.14); border:1px dashed rgba(34,197,94,0.35);
      padding:6px 10px; border-radius:999px;
    }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1><span class="dot"></span> Contact us</h1>
      <!-- <p class="sub">
        This form will <?php echo ($MODE === 'cloud_api') ? 'send your message directly via WhatsApp Cloud API.' : 'open WhatsApp with your message prefilled (you can review & send).'; ?>
        <span class="mode-pill">Mode: <strong><?php echo htmlspecialchars($MODE); ?></strong></span>
      </p> -->

      <?php if ($successMsg): ?>
        <div class="alert ok"><?php echo $successMsg; ?></div>
      <?php endif; ?>
      <?php if ($errorMsg): ?>
        <div class="alert bad"><?php echo $errorMsg; ?></div>
      <?php endif; ?>

      <form method="post" action="">
        <!-- Honeypot -->
        <input class="hp" type="text" name="website" autocomplete="off">

        <div>
          <label for="name">Your name *</label>
          <input id="name" name="name" placeholder="e.g. Islam Ibrahim" required>
        </div>

        <div>
          <label for="phone">Your phone (optional)</label>
          <input id="phone" name="phone" placeholder="+201225853472">
        </div>

        <div class="full">
          <label for="email">Email (optional)</label>
          <input id="email" name="email" type="email" placeholder="contact@safireltafawok.com">
        </div>

        <div class="full">
          <label for="message">Your message *</label>
          <textarea id="message" name="message" placeholder="Write your message..." required></textarea>
        </div>

        <div class="full actions">
          <button type="submit">Send to WhatsApp</button>
          <!-- <span class="note">We’ll never share your details.</span> -->
        </div>
      </form>
    </div>
  </div>
</body>
</html>
